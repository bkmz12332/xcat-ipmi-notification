<meta charset="utf-8">
<?php include_once('func.php'); ?>
<!DOCTYPE html>
<html>
<head>
  <title>последние сообщения от серверов</title>
</head>
<select name='Count' onchange="document.getElementById(this.value).style.display='block';">
<option>размер</option>
<?php
{
	echo dropdown(); 
	  }
?>
</select>

<form method="POST" action="action.php">
            <input type="text" name="first" placeholder="node name">
            <button type="submit" >Send information</button>

        </form>


<div id="vmnode04" style="display: none">1/54</div>

<body>
<?php
{
//Вывод списка пользователей
	echo users();
 //удаление пользователей
}
?>


<?php
{

echo show_node();
}
?>

	
</body>

</html>
