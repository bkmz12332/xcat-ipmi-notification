
<?php
 echo (string)$_POST['first']."<br>"; //выводим запрос из html
 $post = (string)$_POST['first']; // записываем запрос из HTML в переменную
 //echo $post ."<br>";
	  $db = new SQLite3('test.db');
	  $results = $db->query("SELECT * FROM `test` WHERE `node` ='".$post."'"); // запрос с переменной
	  while ($row = $results->fetchArray()) {
		 echo "{$row['node']} {$row['event']} {$row['dat']} \n </br>";

	  }

	  $db->close();
?>
